import React from "react";
import Cart from "../features/cart";

export default function Cartpage(props) {
  return (
    <div>
      <h1>My Cart</h1>
      <Cart />
    </div>
  );
}
